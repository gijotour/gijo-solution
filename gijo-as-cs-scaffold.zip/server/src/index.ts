// GIJO AS 서버 — Express + WebSocket 부트스트랩
// 이 프로세스가 RTX 3090 GPU 머신에서 상시 실행되며, 로컬 LLM·자산DB·SBOM 등
// 상태를 가진 모든 엔진을 단독 소유한다. 클라이언트(Electron 앱)는 여러 대가
// 이 서버 하나에 REST/WebSocket으로 접속한다.

import express from "express";
import cors from "cors";
import { createServer } from "http";
import { WebSocketServer } from "ws";

import { registerAuthRoutes } from "./auth/auth";
import { registerAgentsRoutes } from "./engine/agents";
import { registerDispatcherRoutes } from "./engine/dispatcher";
import { registerMemoryRoutes } from "./engine/memory";
import { registerBridgeRoutes } from "./engine/bridge";
import { registerCollaborationRoutes, attachCollaborationSocket } from "./engine/collaboration";
import { registerDatasetRoutes } from "./engine/dataset";
import { registerGitSyncRoutes } from "./engine/gitsync";
import { registerHfModelsRoutes } from "./engine/hfmodels";
import { registerIntentRoutes } from "./engine/intent";
import { registerLlmRoutes } from "./engine/llm";
import { registerLocalEngineRoutes } from "./engine/localengine";
import { registerFinetuneRoutes, attachFinetuneSocket } from "./engine/finetune";
import { registerToolsRoutes } from "./engine/tools";
import { registerTasksRoutes } from "./engine/tasks";
import { registerEmailRoutes } from "./engine/email";
import { registerSbomRoutes } from "./engine/sbom";
import { registerCtiRoutes } from "./engine/cti";
import { registerReportRoutes } from "./engine/report";

const PORT = Number(process.env.GIJO_SERVER_PORT ?? 4000);

const app = express();
app.use(cors()); // TODO: 온프레미스 배포 시 허용 오리진을 사내망으로 제한
app.use(express.json());

registerAuthRoutes(app);
registerAgentsRoutes(app);
registerDispatcherRoutes(app);
registerMemoryRoutes(app);
registerBridgeRoutes(app);
registerCollaborationRoutes(app);
registerDatasetRoutes(app);
registerGitSyncRoutes(app);
registerHfModelsRoutes(app);
registerIntentRoutes(app);
registerLlmRoutes(app);
registerLocalEngineRoutes(app);
registerFinetuneRoutes(app);
registerToolsRoutes(app);
registerTasksRoutes(app);
registerEmailRoutes(app);
registerSbomRoutes(app);
registerCtiRoutes(app);
registerReportRoutes(app);

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "gijo-as-server" }));

const httpServer = createServer(app);

// 실시간 채널: collaboration:event, finetune:progress 등을 모든 접속 클라이언트에 브로드캐스트
const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
attachCollaborationSocket(wss);
attachFinetuneSocket(wss);

httpServer.listen(PORT, () => {
  console.log(`GIJO AS 서버 기동 — http://localhost:${PORT} (WebSocket: /ws)`);
  console.log("standalone 모드: 클라이언트 GIJO_SERVER_URL을 http://localhost:" + PORT + " 로 설정하면 같은 머신에서 붙습니다.");
});
