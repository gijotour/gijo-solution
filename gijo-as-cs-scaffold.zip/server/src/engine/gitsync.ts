// engine/gitsync.ts — 단기 기억(문서) 온프레미스 Git 동기화 (공개 GitHub 대신, 6.2절 참고)

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

export interface GitSyncConfig {
  remoteUrl: string; // 고객사 내부 Git 서버 주소
  branch: string;
}

export async function syncToInternalGit(config: GitSyncConfig): Promise<void> {
  // TODO: simple-git으로 git init → add → commit → push
}

export function registerGitSyncRoutes(app: Express): void {
  app.post("/api/gitsync/sync", authMiddleware, async (req, res) => {
    await syncToInternalGit(req.body);
    res.json({ ok: true });
  });
}
