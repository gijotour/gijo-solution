// engine/dataset.ts — 파인튜닝용 대화형 데이터셋 변환 · 증폭 (6.2절 ②단계)

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";
import { chat } from "./llm";

export interface ConversationExample {
  question: string;
  answer: string;
}

export async function convertToConversationFormat(rawText: string): Promise<ConversationExample[]> {
  // TODO: chat()을 프롬프트 템플릿과 함께 호출해 Q&A 쌍으로 변환
  return [];
}

export async function amplifyDataset(examples: ConversationExample[], factor = 3): Promise<ConversationExample[]> {
  // TODO: paraphrase augmentation
  return examples;
}

export function registerDatasetRoutes(app: Express): void {
  app.post("/api/dataset/convert", authMiddleware, async (req, res) => {
    res.json(await convertToConversationFormat(req.body.rawText));
  });
  app.post("/api/dataset/amplify", authMiddleware, async (req, res) => {
    res.json(await amplifyDataset(req.body.examples));
  });
}
