// engine/llm.ts — LLM 호출 레이어. llama-server(OpenAI 호환 API)에 요청을 보내는 얇은 클라이언트.
// 서버 프로세스 안에서 localengine.ts가 띄운 llama-server를 호출한다 (같은 머신, localhost).

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

const LOCAL_LLM_BASE_URL = "http://localhost:8080/v1";

export interface ChatArgs {
  agentId: string;
  message: string;
}

export async function chat(args: ChatArgs): Promise<string> {
  const res = await fetch(`${LOCAL_LLM_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "local", messages: [{ role: "user", content: args.message }] }),
  }).catch(() => null);

  if (!res || !res.ok) {
    return "[로컬 LLM 서버에 연결할 수 없습니다. /api/localengine/start 로 먼저 기동하세요.]";
  }
  const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  return data.choices?.[0]?.message?.content ?? "";
}

export function registerLlmRoutes(app: Express): void {
  app.post("/api/llm/chat", authMiddleware, async (req, res) => {
    res.json({ reply: await chat(req.body) });
  });
}
