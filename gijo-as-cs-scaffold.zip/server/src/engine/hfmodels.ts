// engine/hfmodels.ts — HuggingFace 보안 특화 모델 검색 · 불러오기

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

export interface HfModelResult {
  id: string;
  sizeLabel: string;
  format: string;
}

const KNOWN_SECURITY_MODELS: HfModelResult[] = [
  { id: "AlicanKiraz0/Titus-CybersecurityLLM-v1.0", sizeLabel: "21.2GB", format: "GGUF Q4_K_M" },
  { id: "segolilylabs/Lily-Cybersecurity-7B-v0.2", sizeLabel: "4.1GB", format: "GGUF" },
  { id: "fdtn-ai/Foundation-Sec-8B-Instruct", sizeLabel: "4.9GB", format: "GGUF Q4_K_M" },
];

export async function searchHfModels(query: string): Promise<HfModelResult[]> {
  // TODO: HuggingFace Hub API 호출로 대체
  const q = query.toLowerCase();
  return KNOWN_SECURITY_MODELS.filter((m) => m.id.toLowerCase().includes(q) || q.length === 0);
}

export async function loadHfModel(modelId: string): Promise<{ localPath: string }> {
  // TODO: huggingface_hub CLI/REST 다운로드 → 서버의 models/ 폴더에 저장
  throw new Error("not implemented: download " + modelId);
}

export function registerHfModelsRoutes(app: Express): void {
  app.get("/api/hfmodels/search", authMiddleware, async (req, res) => {
    res.json(await searchHfModels(String(req.query.q ?? "")));
  });
  app.post("/api/hfmodels/load", authMiddleware, async (req, res) => {
    res.json(await loadHfModel(req.body.modelId));
  });
}
