// engine/memory.ts — 단기 기억(RAG). 로컬LLM_프로젝트_가이드.md 6.2절 "1차: RAG" 구현체.
// 서버가 LanceDB를 단독 소유하므로 여러 클라이언트가 같은 지식 베이스를 공유해서 질의한다.

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

export interface IngestResult {
  documentId: string;
  chunks: number;
  embeddingModel: string;
}

export async function ingestDocument(filePath: string): Promise<IngestResult> {
  // TODO: 청크 분할 → BGE-M3/multilingual-e5 임베딩 → LanceDB upsert
  throw new Error("not implemented: connect LanceDB client here");
}

export async function queryMemory(question: string, topK = 5): Promise<string[]> {
  // TODO: 질문 임베딩 → LanceDB 유사도 검색 → 상위 K개 컨텍스트 반환
  return [];
}

export function registerMemoryRoutes(app: Express): void {
  app.post("/api/memory/ingest", authMiddleware, async (req, res) => {
    res.json(await ingestDocument(req.body.path));
  });
  app.post("/api/memory/query", authMiddleware, async (req, res) => {
    res.json(await queryMemory(req.body.question));
  });
}
