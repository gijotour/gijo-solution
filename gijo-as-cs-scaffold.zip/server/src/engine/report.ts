// engine/report.ts — 내부 SBOM 기반 내부보고용 리포트 (6.4.1절)

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";
import { chat } from "./llm";

export interface ReportRequest {
  type: "weekly" | "quarterly" | "ondemand";
  assetIds?: string[];
}

export interface ReportResult {
  filePath: string;
  executiveSummary: string;
}

export async function generateReport(req: ReportRequest): Promise<ReportResult> {
  const executiveSummary = await chat({
    agentId: "report",
    message: `다음 보안 현황 데이터를 바탕으로 경영진용 1페이지 요약을 작성해줘: ${JSON.stringify(req)}`,
  });
  // TODO: docx/pdfkit/exceljs 템플릿 엔진 연결
  return { filePath: `reports/${req.type}-${Date.now()}.docx`, executiveSummary };
}

export function registerReportRoutes(app: Express): void {
  app.post("/api/report/generate", authMiddleware, async (req, res) => {
    res.json(await generateReport(req.body));
  });
}
