// engine/sbom.ts — SBOM 생성 · 정리 (CycloneDX / SPDX, 6.4절)

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

export interface SbomComponent {
  name: string;
  version: string;
  license: string;
  knownVulns: string[];
}

export interface SbomDocument {
  assetId: string;
  format: "cyclonedx" | "spdx";
  components: SbomComponent[];
  generatedAt: string;
}

export async function generateSbom(assetId: string): Promise<SbomDocument> {
  // TODO: 자산 레지스트리에서 의존성 조회 후 @cyclonedx/cyclonedx-library로 문서 생성
  return { assetId, format: "cyclonedx", components: [], generatedAt: new Date().toISOString() };
}

export async function exportSbom(assetId: string, format: "cyclonedx" | "spdx"): Promise<string> {
  // TODO: 생성된 SBOM을 JSON/XML로 저장하고 파일 경로 반환
  return `exports/${assetId}.${format}.json`;
}

export function registerSbomRoutes(app: Express): void {
  app.post("/api/sbom/:assetId/generate", authMiddleware, async (req, res) => {
    res.json(await generateSbom(String(req.params.assetId)));
  });
  app.post("/api/sbom/:assetId/export", authMiddleware, async (req, res) => {
    res.json({ path: await exportSbom(String(req.params.assetId), req.body.format) });
  });
}
