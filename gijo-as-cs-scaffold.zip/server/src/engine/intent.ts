// engine/intent.ts — 자연어 명령 의도 파악 및 라우팅

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

export interface RoutedIntent {
  agentId: string;
  action: "scan" | "analyze" | "report" | "chat";
  targetAssetId?: string;
}

export async function routeIntent(text: string): Promise<RoutedIntent> {
  // TODO: 로컬 LLM에 few-shot 프롬프트로 의도 분류를 맡기는 것을 권장.
  if (/스캔|재스캔|scan/i.test(text)) return { agentId: "scan", action: "scan" };
  if (/리포트|보고서|report/i.test(text)) return { agentId: "report", action: "report" };
  if (/우선순위|분석|analy/i.test(text)) return { agentId: "analysis", action: "analyze" };
  return { agentId: "orchestrator", action: "chat" };
}

export function registerIntentRoutes(app: Express): void {
  app.post("/api/intent/route", authMiddleware, async (req, res) => {
    res.json(await routeIntent(req.body.text));
  });
}
