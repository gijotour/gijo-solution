// engine/cti.ts — 딥웹 · 다크웹 CTI 피드 연동 (6.1.1절)
// LLM이 직접 다크웹을 크롤링하지 않고, 라이선스 CTI 벤더 API만 호출한다.

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

export interface CtiFeedConfig {
  id: string;
  name: string;
  apiKey: string;
  connected: boolean;
}

export interface CtiFinding {
  id: string;
  detectedAt: string;
  type: string;
  target: string;
  source: string;
  severity: "info" | "warning" | "critical";
}

const feeds: CtiFeedConfig[] = [
  { id: "criminalip", name: "Criminal IP", apiKey: "", connected: false },
  { id: "flashpoint", name: "Flashpoint", apiKey: "", connected: false },
  { id: "spycloud", name: "SpyCloud", apiKey: "", connected: false },
];

export async function listFindings(): Promise<CtiFinding[]> {
  // TODO: 연결된 각 피드의 REST API 호출해 최근 탐지 내역 취합
  return [];
}

export function registerCtiRoutes(app: Express): void {
  app.get("/api/cti/feeds", authMiddleware, (_req, res) => res.json(feeds));
  app.get("/api/cti/findings", authMiddleware, async (_req, res) => res.json(await listFindings()));
}
