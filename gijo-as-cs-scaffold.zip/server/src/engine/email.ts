// engine/email.ts — 내부 리포트 이메일 발송 (6.4.1절)

import type { Express } from "express";
import { authMiddleware } from "../auth/auth";

export interface SendReportEmailArgs {
  to: string[];
  subject: string;
  attachmentPath: string;
}

export async function sendReportEmail(args: SendReportEmailArgs): Promise<void> {
  // TODO: nodemailer 등으로 사내 SMTP 서버 연동
}

export function registerEmailRoutes(app: Express): void {
  app.post("/api/email/sendReport", authMiddleware, async (req, res) => {
    await sendReportEmail(req.body);
    res.json({ ok: true });
  });
}
