# GIJO AS — 서버/클라이언트(CS) 구조

`로컬LLM_프로젝트_가이드.md` 7~9단계에서 설계한 단일 Electron 앱을
클라이언트-서버(CS) 구조로 전환한 버전입니다.

## 왜 CS 구조인가

- GIJO AS의 원래 기획서에도 오케스트레이터가 "보안 AI 중계서버"로 명명되어 있었습니다 —
  CS 구조가 원래 의도된 방향이었음을 확인했습니다.
- 로컬 LLM(RTX 3090), 자산 DB, SBOM/CTI 데이터는 상태를 가지며 GPU 리소스가 필요합니다 —
  여러 보안담당자가 각자 PC에서 접속하되 실제 연산/데이터는 서버 한 대(또는 사내 서버실)에
  집중하는 편이 기업 고객(특히 금융권 온프레미스 요구)에 적합합니다.
- 클라이언트를 얇게 유지하면 배포/업데이트가 클라이언트 재설치만으로 끝나고,
  민감한 로직·자격증명은 서버에만 존재합니다.

## 구조

```
cs/
├── server/     Express + WebSocket. 15개 상태/GPU/DB 모듈 전부 여기서 실행.
│               (localengine, memory, bridge, finetune, dataset, hfmodels,
│                sbom, cti, report, tasks, collaboration, agents, gitsync,
│                cryptopack, email) + 인증(auth)
└── client/     Electron. 창 관리 + REST/WebSocket 호출만 담당하는 얇은 클라이언트.
                intent/llm/tools 라우팅도 서버 API 호출로 대체됨(로직은 서버에 있음).
```

## 실행 방법(스캐폴드 기준 — 실제 npm install은 GitHub 접근 가능한 환경에서 실행)

### 단일 데스크톱 모드(1인 기업/소규모, 서버+클라이언트를 한 PC에)

```
cd server && npm install && npm run build
cd ../client && npm install && npm run build
npm start   # client가 자동으로 로컬 서버를 기동하고 localhost:4000에 접속
```

### 분산 모드(기업 고객, GPU 서버 1대 + 보안담당자 여러 PC)

```
# RTX 3090 서버 머신에서
cd server && npm install && npm run build && npm start   # 0.0.0.0:4000 상시 실행

# 각 보안담당자 PC에서
cd client && npm install && npm run build
GIJO_SERVER_URL=http://<서버-IP>:4000 npm start
# 또는 로그인 화면에서 서버 주소를 직접 입력
```

## 인증

`server/src/auth/users.ts`에 보안담당자 계정을 등록합니다(현재 시드 계정 1개, 평문 비교 —
프로덕션 적용 전 bcrypt 해시로 교체 필요). 로그인 시 발급되는 Bearer 토큰으로
모든 API 요청과 WebSocket 연결이 인증됩니다.

## 알려진 미결 항목

- 비밀번호 해시화(bcrypt), 세션 영속화(현재는 서버 재시작 시 전원 로그아웃)
- CORS는 현재 전체 허용(`app.use(cors())`) — 온프레미스 배포 시 사내망 오리진으로 제한 필요
- 자산 인벤토리(assets) 전용 API 라우트 없음 — inventory.html은 목업 데이터로 동작
- 서버 쪽 언어를 Node/TS로 유지할지 Java/Spring으로 갈지는 보류 상태
  (`로컬LLM_프로젝트_가이드.md` 9단계 메모 참고, 이번 CS 전환에서는 결정하지 않음)
