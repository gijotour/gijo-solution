// GIJO AS 클라이언트 — API Client
// 서버(gijo-as-server)와의 모든 통신은 이 모듈을 통해서만 이루어진다.
// preload.ts가 이 모듈을 사용해 window.gijo.* 표면을 구성한다.
//
// 인증: 로그인 성공 시 서버가 발급한 Bearer 토큰을 모듈 내부 변수에 보관한다.
// (프로덕션에서는 OS 자격 증명 저장소 연동을 검토할 것 — 현재는 스캐폴드 수준)

const DEFAULT_SERVER_URL = process.env.GIJO_SERVER_URL ?? "http://localhost:4000";

let serverUrl = DEFAULT_SERVER_URL;
let authToken: string | null = null;

export function setServerUrl(url: string): void {
  serverUrl = url.replace(/\/+$/, "");
}

export function getServerUrl(): string {
  return serverUrl;
}

export function setAuthToken(token: string | null): void {
  authToken = token;
}

export function isAuthenticated(): boolean {
  return authToken !== null;
}

interface RequestOpts {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
}

async function request<T = unknown>(path: string, opts: RequestOpts = {}): Promise<T> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (authToken) headers["Authorization"] = `Bearer ${authToken}`;

  const res = await fetch(`${serverUrl}${path}`, {
    method: opts.method ?? "GET",
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });

  if (!res.ok) {
    let detail = "";
    try {
      detail = JSON.stringify(await res.json());
    } catch {
      /* 응답 본문이 JSON이 아닌 경우 무시 */
    }
    throw new Error(`GIJO AS 서버 오류 ${res.status} ${path} ${detail}`);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

// ── 인증 ──────────────────────────────────────────────────────────────
export const authApi = {
  login: async (username: string, password: string) => {
    const result = await request<{ token: string; user: unknown }>("/api/auth/login", {
      method: "POST",
      body: { username, password },
    });
    setAuthToken(result.token);
    return result;
  },
  logout: async () => {
    await request("/api/auth/logout", { method: "POST" });
    setAuthToken(null);
  },
  me: () => request("/api/auth/me"),
};

// ── 에이전트 AI ───────────────────────────────────────────────────────
export const agentsApi = {
  list: () => request("/api/agents"),
};

// ── 지시(디스패처) ────────────────────────────────────────────────────
export const dispatchApi = {
  send: (instructionText: string) =>
    request("/api/dispatch", { method: "POST", body: { instructionText } }),
};

// ── 작업 큐 ───────────────────────────────────────────────────────────
export const tasksApi = {
  list: () => request("/api/tasks"),
  add: (text: string) => request("/api/tasks", { method: "POST", body: { text } }),
  complete: (id: string) => request(`/api/tasks/${id}/complete`, { method: "POST" }),
};

// ── 협업 로그 ─────────────────────────────────────────────────────────
export const collaborationApi = {
  history: () => request("/api/collaboration/history"),
};

// ── 메모리(RAG) ───────────────────────────────────────────────────────
export const memoryApi = {
  ingest: (path: string) => request("/api/memory/ingest", { method: "POST", body: { path } }),
  query: (query: string) => request("/api/memory/query", { method: "POST", body: { query } }),
};

// ── LLM 브리지 / 채팅 ─────────────────────────────────────────────────
export const bridgeApi = {
  run: (payload: unknown) => request("/api/bridge/run", { method: "POST", body: payload }),
  adapters: () => request("/api/bridge/adapters"),
};

export const llmApi = {
  chat: (agentId: string, message: string) =>
    request("/api/llm/chat", { method: "POST", body: { agentId, message } }),
};

// ── 로컬 엔진(llama.cpp 서버) ─────────────────────────────────────────
export const localEngineApi = {
  status: () => request("/api/localengine/status"),
  start: (modelId: string) => request("/api/localengine/start", { method: "POST", body: { modelId } }),
  stop: () => request("/api/localengine/stop", { method: "POST" }),
};

// ── 파인튜닝(장기 기억) ───────────────────────────────────────────────
export const finetuneApi = {
  start: (agentId: string, datasetId: string) =>
    request("/api/finetune/start", { method: "POST", body: { agentId, datasetId } }),
};

// ── 데이터셋 ──────────────────────────────────────────────────────────
export const datasetApi = {
  convert: (path: string) => request("/api/dataset/convert", { method: "POST", body: { path } }),
  amplify: (datasetId: string) => request("/api/dataset/amplify", { method: "POST", body: { datasetId } }),
};

// ── HuggingFace 모델 ──────────────────────────────────────────────────
export const hfModelsApi = {
  search: (query: string) => request(`/api/hfmodels/search?q=${encodeURIComponent(query)}`),
  load: (modelId: string) => request("/api/hfmodels/load", { method: "POST", body: { modelId } }),
};

// ── Git 동기화 ────────────────────────────────────────────────────────
export const gitSyncApi = {
  sync: (repoUrl: string) => request("/api/gitsync/sync", { method: "POST", body: { repoUrl } }),
};

// ── 의도 라우팅 ───────────────────────────────────────────────────────
export const intentApi = {
  route: (text: string) => request("/api/intent/route", { method: "POST", body: { text } }),
};

// ── 도구(Tools) ───────────────────────────────────────────────────────
export const toolsApi = {
  list: () => request("/api/tools"),
  run: (toolId: string, args: unknown) => request("/api/tools/run", { method: "POST", body: { toolId, args } }),
};

// ── 이메일 리포트 발송 ────────────────────────────────────────────────
export const emailApi = {
  sendReport: (to: string, reportId: string) =>
    request("/api/email/sendReport", { method: "POST", body: { to, reportId } }),
};

// ── SBOM ─────────────────────────────────────────────────────────────
export const sbomApi = {
  generate: (assetId: string) => request(`/api/sbom/${assetId}/generate`, { method: "POST" }),
  export: (assetId: string, format: "cyclonedx" | "spdx") =>
    request(`/api/sbom/${assetId}/export`, { method: "POST", body: { format } }),
};

// ── CTI(위협 인텔리전스) ──────────────────────────────────────────────
export const ctiApi = {
  feeds: () => request("/api/cti/feeds"),
  findings: () => request("/api/cti/findings"),
};

// ── 내부 리포트 ───────────────────────────────────────────────────────
export const reportApi = {
  generate: (type: "weekly" | "quarterly" | "ondemand", assetIds?: string[]) =>
    request("/api/report/generate", { method: "POST", body: { type, assetIds } }),
};

// ── 서버 헬스체크 ─────────────────────────────────────────────────────
export const healthApi = {
  check: () => request<{ ok: boolean; service: string }>("/api/health"),
};

// 참고: "자산 인벤토리 목록"(assets:list)은 서버에 전용 라우트가 아직 없다.
// 자산 인벤토리 화면(02_자산인벤토리.html)은 현재 목업 데이터로 동작하며,
// 실 배포 전 engine/assets.ts(가칭) 라우트 추가가 필요하다 — 알려진 미결 항목으로 남겨둔다.
