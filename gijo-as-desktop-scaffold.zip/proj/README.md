# GIJO AS Desktop — 프로젝트 스캐폴드

GIJO AS(AI SBOM · Security Manager Platform)의 Electron 데스크톱 앱 초기 뼈대입니다.
자세한 배경, 하드웨어 사양, 개발 착수 체크리스트는 `로컬LLM_프로젝트_가이드.md`(Connect AI 폴더에 별도 보관)를 참고하세요.

## 구조

```
src/
├── main.ts              메인 프로세스 진입점 (얇게 유지, 기능은 engine/에 위임)
├── preload.ts            contextBridge로 렌더러에 안전한 API(window.gijo) 노출
├── engine/                기능별 독립 모듈 (7.2절 모듈 대응표와 1:1 대응)
│   ├── agents.ts          8종 보안 에이전트 정의
│   ├── memory.ts          RAG 단기 기억 (LanceDB 연동 예정)
│   ├── bridge.ts          ModelScan/Penligent 등 스캐너 어댑터 브릿지
│   ├── collaboration.ts   에이전트 간 협업 로그
│   ├── dataset.ts         파인튜닝용 대화형 데이터셋 변환·증폭
│   ├── gitsync.ts         온프레미스 Git 서버 동기화
│   ├── hfmodels.ts        HuggingFace 보안 모델 검색·불러오기
│   ├── intent.ts          자연어 지시 → 에이전트 라우팅
│   ├── llm.ts             llama-server REST 클라이언트
│   ├── localengine.ts     llama-server 프로세스 관리
│   ├── finetune.ts        QLoRA 파인튜닝 파이프라인 (Unsloth)
│   ├── tools.ts           에이전트 실행 가능 툴 레지스트리
│   ├── tasks.ts           오늘 확인할 항목(P0~P1) 큐
│   ├── dispatcher.ts      지시 → 할당 → 실행 → 로그 전체 파이프라인 조율 (신규)
│   ├── email.ts           내부 리포트 이메일 발송
│   ├── cryptopack.ts      민감 데이터 암호화 유틸
│   ├── sbom.ts            CycloneDX/SPDX SBOM 생성·내보내기
│   ├── cti.ts             딥웹·다크웹 CTI 피드 연동
│   └── report.ts          내부 SBOM 기반 리포트 생성
└── renderer/
    ├── core.ts            렌더러 공통 로직 (사이드바 nav, 채팅바 wiring)
    └── pages/             8개 화면 HTML (기존 UI 목업을 그대로 사용)
        ├── dashboard.html
        ├── inventory.html
        ├── sbom.html
        ├── threat.html
        ├── merge.html
        ├── report.html
        ├── billing.html
        └── agent.html
```

## 시작하기 (서버 PC 인수 후)

```powershell
npm install
npm run build
npm start
```

## 지시 실행 파이프라인 (dispatcher.ts)

대시보드/에이전트 AI 화면 채팅바에 입력한 지시문은 다음 순서로 처리됩니다.

1. `intent.routeIntent()` — 지시문 → 담당 에이전트 · 액션 판단
2. `tasks.createTask()` — 작업 큐에 기록 (대시보드 "오늘 확인할 항목"에 반영)
3. `agents.setAgentStatus("working")` — 해당 에이전트 상태 변경
4. `collaboration.emitCollaboration()` — 할당 로그 기록
5. `bridge.runAdapter()` 또는 `llm.chat()` — 실제 실행
6. `collaboration.emitCollaboration()` — 완료 로그 기록
7. `agents.resetAgentToDefault()` + `tasks.completeTask()` — 마무리

`preload.ts`의 `sendInstruction()`이 `dispatcher:run` 채널을 호출하므로, 렌더러 쪽 코드 변경 없이 채팅바 입력이 이 파이프라인을 그대로 탄다.

## 다음 작업 (TODO 우선순위)

1. `engine/localengine.ts` — llama-server 실제 프로세스 기동 경로 확인 (1로컬LLM_프로젝트_가이드.md 1~3단계 먼저 완료)
2. `engine/memory.ts` — LanceDB 클라이언트 연결
3. `engine/bridge.ts` — ModelScan 어댑터 실제 연동 (Penligent는 2번째 어댑터로 후순위)
4. `renderer/pages/*.html` 각 파일에 `<script src="../core.js">` 추가하고, mock 데이터를 `window.gijo.*` 실제 호출로 교체
5. `engine/sbom.ts`, `engine/report.ts` — CycloneDX 라이브러리·docx 템플릿 연결

각 항목의 기술 스택·난이도·우선순위 근거는 `로컬LLM_프로젝트_가이드.md` 6단계를 참고하세요.
