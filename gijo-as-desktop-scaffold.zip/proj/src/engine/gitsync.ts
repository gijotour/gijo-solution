// engine/gitsync.ts — 단기 기억(문서) 온프레미스 Git 동기화
// Connect AI는 공개 GitHub로 동기화하지만, GIJO AS는 보안 제품 특성상
// 고객사 내부 Git 서버(온프레미스)로 대체한다. (6.2절 참고 박스)

import type { IpcMain } from "electron";

export interface GitSyncConfig {
  remoteUrl: string; // 고객사 내부 Git 서버 주소
  branch: string;
}

export async function syncToInternalGit(config: GitSyncConfig): Promise<void> {
  // TODO: simple-git 등으로 git init → add → commit → push 구현
  // 주의: 고객사 데이터이므로 원격 저장소는 반드시 온프레미스/사설망으로 제한
}

export function registerGitSyncEngine(ipcMain: IpcMain): void {
  ipcMain.handle("gitsync:sync", async (_e, config: GitSyncConfig) => syncToInternalGit(config));
}
