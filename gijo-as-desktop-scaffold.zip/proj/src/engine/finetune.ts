// engine/finetune.ts — QLoRA 파인튜닝 파이프라인 (Unsloth 기반)
// 로컬LLM_프로젝트_가이드.md 6.2절 ③단계 구현체.
// 실제 학습은 Python(Unsloth) 스크립트를 서브프로세스로 실행하고,
// stdout의 Loss 로그를 파싱해 진행률 이벤트로 렌더러에 전달한다.

import type { IpcMain, BrowserWindow } from "electron";
import { spawn } from "child_process";

export interface FinetuneArgs {
  agentId: string;
  datasetId: string;
}

export interface FinetuneProgress {
  step: number;
  maxSteps: number;
  loss: number;
}

export function startFinetune(win: BrowserWindow, args: FinetuneArgs): void {
  // TODO: scripts/finetune_unsloth.py 실행, --dataset / --base-model 인자 전달
  const proc = spawn("python", ["scripts/finetune_unsloth.py", "--dataset", args.datasetId]);

  proc.stdout.on("data", (chunk: Buffer) => {
    // TODO: 실제 로그 포맷에 맞춰 정규식 파싱 (예: "step 120/400 loss=0.83")
    const text = chunk.toString();
    const match = /step\s+(\d+)\/(\d+)\s+loss=([\d.]+)/.exec(text);
    if (match) {
      const progress: FinetuneProgress = {
        step: Number(match[1]),
        maxSteps: Number(match[2]),
        loss: Number(match[3]),
      };
      win.webContents.send("finetune:progress", progress);
    }
  });
}

export function registerFinetuneEngine(ipcMain: IpcMain): void {
  ipcMain.handle("finetune:start", async (event, args: FinetuneArgs) => {
    const win = require("electron").BrowserWindow.fromWebContents(event.sender);
    if (win) startFinetune(win, args);
    return { started: true };
  });
}
