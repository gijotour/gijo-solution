// engine/dispatcher.ts — 지시 → 할당 → 실행 → 로그까지 잇는 조율 로직
//
// 순서: intent.routeIntent() → tasks.createTask() → agents.setAgentStatus("working")
//       → collaboration 로그(할당) → bridge/llm 실행 → collaboration 로그(완료)
//       → agents.resetAgentToDefault() → tasks.completeTask()
//
// 대시보드/에이전트 AI 화면의 채팅바에서 보안담당자가 입력한 지시문 하나가
// 이 함수 하나를 통과하며 전체 파이프라인을 돈다.

import type { IpcMain, BrowserWindow } from "electron";
import { routeIntent, RoutedIntent } from "./intent";
import { createTask, completeTask, TaskItem } from "./tasks";
import { setAgentStatus, resetAgentToDefault, getAgentById } from "./agents";
import { emitCollaboration } from "./collaboration";
import { runAdapter } from "./bridge";
import { chat } from "./llm";

export interface DispatchResult {
  task: TaskItem;
  route: RoutedIntent;
  output: string;
}

/** action → 초기 우선순위 매핑 (간단한 휴리스틱, 추후 LLM 기반 우선순위 판단으로 교체 가능) */
function priorityForAction(action: RoutedIntent["action"]): TaskItem["priority"] {
  if (action === "scan") return "P1";
  if (action === "analyze") return "P1";
  if (action === "report") return "P2";
  return "P2"; // chat
}

/**
 * 실제 작업 실행. action 종류에 따라 bridge(스캐너 어댑터) 또는 llm(대화)로 위임한다.
 * TODO: targetAssetId → 실제 자산 파일 경로 조회는 자산 레지스트리 모듈이 생기면 연결
 */
async function executeRoutedAction(route: RoutedIntent, instructionText: string): Promise<string> {
  switch (route.action) {
    case "scan": {
      const assetPath = route.targetAssetId ?? "unknown-asset";
      const findings = await runAdapter("modelscan", assetPath).catch((err) => {
        return [{ finding_type: "scan_error", severity: "low" as const, evidence: String(err), source_tool: "modelscan" }];
      });
      return `스캔 완료 — ${findings.length}건 발견`;
    }
    case "analyze":
    case "report":
    case "chat":
    default:
      return chat({ agentId: route.agentId, message: instructionText });
  }
}

export async function dispatchInstruction(win: BrowserWindow, instructionText: string): Promise<DispatchResult> {
  // 1) 지시문 → 담당 에이전트/액션 판단
  const route = await routeIntent(instructionText);
  const agent = getAgentById(route.agentId);

  // 2) 작업 큐에 기록 (대시보드 "오늘 확인할 항목"에 즉시 반영됨)
  const task = createTask({
    text: instructionText,
    agentId: route.agentId,
    priority: priorityForAction(route.action),
  });

  // 3) 에이전트 상태 변경 + 할당 로그
  setAgentStatus(route.agentId, "working");
  emitCollaboration(win, {
    from: "orchestrator",
    to: route.agentId,
    message: `작업 할당: "${instructionText}"`,
  });

  // 4) 실제 실행 (실패해도 파이프라인은 끝까지 진행 — 실패 사유를 결과로 남김)
  let output: string;
  try {
    output = await executeRoutedAction(route, instructionText);
  } catch (err) {
    output = `실행 실패: ${err instanceof Error ? err.message : String(err)}`;
  }

  // 5) 완료 로그 + 상태 복귀 + 작업 완료 처리
  emitCollaboration(win, {
    from: route.agentId,
    to: "orchestrator",
    message: `작업 완료: ${output}`,
  });
  resetAgentToDefault(route.agentId);
  completeTask(task.id);

  return { task, route, output };
}

export function registerDispatcherEngine(ipcMain: IpcMain): void {
  ipcMain.handle("dispatcher:run", async (event, instructionText: string) => {
    const { BrowserWindow } = require("electron");
    const win = BrowserWindow.fromWebContents(event.sender);
    if (!win) throw new Error("no window associated with this request");
    return dispatchInstruction(win, instructionText);
  });
}
