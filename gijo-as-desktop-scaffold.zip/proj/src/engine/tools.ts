// engine/tools.ts — 에이전트가 실행 가능한 액션(툴) 정의
// ModelScan/Penligent 등 스캐너 어댑터를 에이전트가 호출 가능한 "툴"로 등록한다.

import type { IpcMain } from "electron";

export interface ToolDefinition {
  name: string;
  description: string;
  run: (args: Record<string, unknown>) => Promise<unknown>;
}

const registry: Record<string, ToolDefinition> = {};

export function registerTool(tool: ToolDefinition): void {
  registry[tool.name] = tool;
}

export function registerToolsEngine(ipcMain: IpcMain): void {
  ipcMain.handle("tools:list", async () =>
    Object.values(registry).map(({ name, description }) => ({ name, description }))
  );
  ipcMain.handle("tools:run", async (_e, args: { name: string; params: Record<string, unknown> }) => {
    const tool = registry[args.name];
    if (!tool) throw new Error(`unknown tool: ${args.name}`);
    return tool.run(args.params);
  });
  // TODO: bridge.ts의 어댑터들을 여기서 registerTool()로 등록
}
