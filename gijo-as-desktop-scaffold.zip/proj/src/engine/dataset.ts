// engine/dataset.ts — 파인튜닝용 대화형 데이터셋 변환 · 증폭
// 로컬LLM_프로젝트_가이드.md 6.2절 ②단계: RAG 문서를 Q&A 포맷으로 변환한다.

import type { IpcMain } from "electron";

export interface ConversationExample {
  question: string;
  answer: string;
}

export async function convertToConversationFormat(rawText: string): Promise<ConversationExample[]> {
  // TODO: LLM을 호출해 원문 텍스트를 질문-답변 쌍으로 변환
  // (llm.ts의 chat()을 재사용, 프롬프트 템플릿은 별도 관리)
  return [];
}

export async function amplifyDataset(examples: ConversationExample[], factor = 3): Promise<ConversationExample[]> {
  // TODO: 동일 의미를 다른 표현으로 재작성해 데이터 양을 늘림 (paraphrase augmentation)
  return examples;
}

export function registerDatasetEngine(ipcMain: IpcMain): void {
  ipcMain.handle("dataset:convert", async (_e, rawText: string) => convertToConversationFormat(rawText));
  ipcMain.handle("dataset:amplify", async (_e, examples: ConversationExample[]) => amplifyDataset(examples));
}
