// engine/localengine.ts — 로컬 LLM 엔진(llama-server) 프로세스 관리
// 로컬LLM_프로젝트_가이드.md 4.1절 구현체.

import type { IpcMain } from "electron";
import { spawn, ChildProcess } from "child_process";
import * as path from "path";

let serverProcess: ChildProcess | null = null;

export interface LocalEngineStatus {
  running: boolean;
  port: number;
  modelId: string | null;
}

let currentModelId: string | null = null;

export async function startLocalEngine(modelId: string): Promise<LocalEngineStatus> {
  if (serverProcess) {
    return { running: true, port: 8080, modelId: currentModelId };
  }
  // TODO: modelId → 실제 GGUF 파일 경로 매핑 테이블 필요 (models/manifest.json 등)
  const modelPath = path.join("models", modelId, `${modelId}.gguf`);

  serverProcess = spawn(
    path.join("llama.cpp", "build", "bin", "Release", "llama-server.exe"),
    ["-m", modelPath, "-ngl", "-1", "--ctx-size", "32768", "--port", "8080"],
    { stdio: "pipe" }
  );
  currentModelId = modelId;

  serverProcess.on("exit", () => {
    serverProcess = null;
    currentModelId = null;
  });

  return { running: true, port: 8080, modelId };
}

export function stopLocalEngine(): void {
  serverProcess?.kill();
  serverProcess = null;
  currentModelId = null;
}

export function registerLocalEngine(ipcMain: IpcMain): void {
  ipcMain.handle("localengine:status", async (): Promise<LocalEngineStatus> => ({
    running: !!serverProcess,
    port: 8080,
    modelId: currentModelId,
  }));
  ipcMain.handle("localengine:start", async (_e, modelId: string) => startLocalEngine(modelId));
  ipcMain.handle("localengine:stop", async () => stopLocalEngine());
}
