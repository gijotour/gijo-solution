// engine/llm.ts — LLM 호출 레이어
// llama-server(OpenAI 호환 API)에 요청을 보내는 얇은 클라이언트.
// 로컬LLM_프로젝트_가이드.md 3.2 / 3.3절 참고.

import type { IpcMain } from "electron";

const LOCAL_LLM_BASE_URL = "http://localhost:8080/v1";

export interface ChatArgs {
  agentId: string;
  message: string;
}

export async function chat(args: ChatArgs): Promise<string> {
  // TODO: node-fetch로 실제 호출. 에이전트별 system prompt는 agents.ts의
  // brainModelId / role 정보를 바탕으로 구성한다.
  const res = await fetch(`${LOCAL_LLM_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "local",
      messages: [{ role: "user", content: args.message }],
    }),
  }).catch(() => null);

  if (!res || !res.ok) {
    return "[로컬 LLM 서버에 연결할 수 없습니다. localengine:start 로 먼저 기동하세요.]";
  }
  const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  return data.choices?.[0]?.message?.content ?? "";
}

export function registerLlmEngine(ipcMain: IpcMain): void {
  ipcMain.handle("llm:chat", async (_e, args: ChatArgs) => chat(args));
}
