// engine/hfmodels.ts — HuggingFace 보안 특화 모델 검색 · 불러오기
// 에이전트 AI 화면의 "HuggingFace 모델 검색 · 불러오기" 패널 구현체.

import type { IpcMain } from "electron";

export interface HfModelResult {
  id: string;
  sizeLabel: string;
  format: string;
}

// 로컬LLM_프로젝트_가이드.md 6.3절에서 조사한 후보들을 기본 추천 목록으로 시딩
const KNOWN_SECURITY_MODELS: HfModelResult[] = [
  { id: "AlicanKiraz0/Titus-CybersecurityLLM-v1.0", sizeLabel: "21.2GB", format: "GGUF Q4_K_M" },
  { id: "segolilylabs/Lily-Cybersecurity-7B-v0.2", sizeLabel: "4.1GB", format: "GGUF" },
  { id: "fdtn-ai/Foundation-Sec-8B-Instruct", sizeLabel: "4.9GB", format: "GGUF Q4_K_M" },
];

export async function searchHfModels(query: string): Promise<HfModelResult[]> {
  // TODO: HuggingFace Hub API(https://huggingface.co/api/models?search=...) 호출로 대체
  const q = query.toLowerCase();
  return KNOWN_SECURITY_MODELS.filter((m) => m.id.toLowerCase().includes(q) || q.length === 0);
}

export async function loadHfModel(modelId: string): Promise<{ localPath: string }> {
  // TODO: huggingface_hub CLI 또는 REST 다운로드 후 로컬 models/ 폴더에 저장
  throw new Error("not implemented: download " + modelId);
}

export function registerHfModelsEngine(ipcMain: IpcMain): void {
  ipcMain.handle("hfmodels:search", async (_e, query: string) => searchHfModels(query));
  ipcMain.handle("hfmodels:load", async (_e, modelId: string) => loadHfModel(modelId));
}
