// engine/intent.ts — 자연어 명령 의도 파악 및 라우팅
// 대시보드 하단 채팅바에 입력한 지시를 적절한 에이전트/엔진으로 라우팅한다.

import type { IpcMain } from "electron";
import { DEFAULT_AGENTS } from "./agents";

export interface RoutedIntent {
  agentId: string;
  action: "scan" | "analyze" | "report" | "chat";
  targetAssetId?: string;
}

export async function routeIntent(text: string): Promise<RoutedIntent> {
  // TODO: 로컬 LLM(llm.ts)에 few-shot 프롬프트로 의도 분류를 맡기는 것을 권장.
  // 임시 규칙 기반 라우팅 (초기 스캐폴딩용):
  if (/스캔|재스캔|scan/i.test(text)) return { agentId: "scan", action: "scan" };
  if (/리포트|보고서|report/i.test(text)) return { agentId: "report", action: "report" };
  if (/우선순위|분석|analy/i.test(text)) return { agentId: "analysis", action: "analyze" };
  return { agentId: "orchestrator", action: "chat" };
}

export function registerIntentEngine(ipcMain: IpcMain): void {
  ipcMain.handle("intent:route", async (_e, text: string) => routeIntent(text));
}
