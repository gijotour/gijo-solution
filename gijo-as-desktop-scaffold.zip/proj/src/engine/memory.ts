// engine/memory.ts — 단기 기억(RAG) 관리
// 로컬LLM_프로젝트_가이드.md 6.2절 "1차: RAG" 구현체.
// 문서를 임베딩해 로컬 벡터DB(LanceDB)에 저장하고, 질의 시 유사 컨텍스트를 검색한다.

import type { IpcMain } from "electron";

export interface IngestResult {
  documentId: string;
  chunks: number;
  embeddingModel: string;
}

export async function ingestDocument(filePath: string): Promise<IngestResult> {
  // TODO:
  // 1) 파일 로드 및 청크 분할
  // 2) BGE-M3 / multilingual-e5 등 임베딩 모델로 벡터화
  // 3) LanceDB 테이블에 upsert
  throw new Error("not implemented: connect LanceDB client here");
}

export async function queryMemory(question: string, topK = 5): Promise<string[]> {
  // TODO: 질문을 임베딩 → LanceDB 유사도 검색 → 상위 K개 컨텍스트 반환
  return [];
}

export function registerMemoryEngine(ipcMain: IpcMain): void {
  ipcMain.handle("memory:ingest", async (_e, filePath: string) => ingestDocument(filePath));
  ipcMain.handle("memory:query", async (_e, question: string) => queryMemory(question));
}
