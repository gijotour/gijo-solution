// engine/tasks.ts — 작업 큐 관리
// 대시보드 "오늘 확인할 항목"(P0~P1) 큐 구현체.
// dispatcher.ts가 지시를 받으면 여기에 작업을 생성하고, 완료 시 done=true로 갱신한다.

import type { IpcMain } from "electron";

export interface TaskItem {
  id: string;
  priority: "P0" | "P1" | "P2" | "P3";
  text: string;
  agentId?: string; // 어떤 에이전트에게 할당됐는지 — 수동으로 추가한 할일은 비어있을 수 있음
  done: boolean;
  createdAt: number;
}

let tasks: TaskItem[] = [];

export function createTask(args: { text: string; agentId?: string; priority?: TaskItem["priority"] }): TaskItem {
  const item: TaskItem = {
    id: String(Date.now()) + Math.random().toString(36).slice(2, 6),
    priority: args.priority ?? "P2",
    text: args.text,
    agentId: args.agentId,
    done: false,
    createdAt: Date.now(),
  };
  tasks.push(item);
  return item;
}

export function completeTask(id: string): TaskItem[] {
  tasks = tasks.map((t) => (t.id === id ? { ...t, done: true } : t));
  return tasks;
}

export function listTasks(): TaskItem[] {
  return tasks;
}

export function registerTasksEngine(ipcMain: IpcMain): void {
  ipcMain.handle("tasks:list", async () => listTasks());
  ipcMain.handle("tasks:add", async (_e, text: string) => createTask({ text }));
  ipcMain.handle("tasks:complete", async (_e, id: string) => completeTask(id));
}
