// engine/bridge.ts — 오케스트레이터 ↔ 스캐너 어댑터 브릿지
// ModelScan, Penligent 등 외부 점검툴을 플러그인 형태로 명령·취합한다.

import type { IpcMain } from "electron";
import { execFile } from "child_process";

export interface ScanAdapter {
  id: string;
  name: string;
  run: (assetPath: string) => Promise<StandardFinding[]>;
}

export interface StandardFinding {
  finding_type: string;
  severity: "low" | "medium" | "high" | "critical";
  evidence: string;
  source_tool: string;
}

// TODO: 각 어댑터를 실제 CLI/서브프로세스 호출로 구현
const adapters: Record<string, ScanAdapter> = {
  modelscan: {
    id: "modelscan",
    name: "ModelScan",
    run: (assetPath) =>
      new Promise((resolve, reject) => {
        execFile("python", ["modelscan_wrapper.py", assetPath], (err, stdout) => {
          if (err) return reject(err);
          try {
            resolve(JSON.parse(stdout) as StandardFinding[]);
          } catch (e) {
            reject(e);
          }
        });
      }),
  },
  // penligent: { ... } // TODO: Penligent 어댑터 추가
};

/** dispatcher.ts 등 다른 엔진 모듈에서 직접 호출할 수 있는 순수 함수 버전 */
export async function runAdapter(adapterId: string, assetPath: string): Promise<StandardFinding[]> {
  const adapter = adapters[adapterId];
  if (!adapter) throw new Error(`unknown adapter: ${adapterId}`);
  return adapter.run(assetPath);
}

export function listAdapters(): { id: string; name: string }[] {
  return Object.values(adapters).map(({ id, name }) => ({ id, name }));
}

export function registerBridgeEngine(ipcMain: IpcMain): void {
  ipcMain.handle("bridge:runAdapter", async (_e, args: { adapterId: string; assetPath: string }) =>
    runAdapter(args.adapterId, args.assetPath)
  );
  ipcMain.handle("bridge:listAdapters", async () => listAdapters());
}
