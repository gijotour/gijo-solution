// engine/sbom.ts — SBOM 생성 · 정리 (CycloneDX / SPDX)
// 로컬LLM_프로젝트_가이드.md 6.4절 구현체.

import type { IpcMain } from "electron";

export interface SbomComponent {
  name: string;
  version: string;
  license: string;
  knownVulns: string[];
}

export interface SbomDocument {
  assetId: string;
  format: "cyclonedx" | "spdx";
  components: SbomComponent[];
  generatedAt: string;
}

export async function generateSbom(assetId: string): Promise<SbomDocument> {
  // TODO: 자산 레지스트리(LanceDB)에서 의존성 정보 조회 후
  // @cyclonedx/cyclonedx-library 등으로 실제 문서 생성
  return { assetId, format: "cyclonedx", components: [], generatedAt: new Date().toISOString() };
}

export async function exportSbom(assetId: string, format: "cyclonedx" | "spdx"): Promise<string> {
  // TODO: 생성된 SBOM을 JSON/XML 파일로 저장하고 파일 경로 반환
  return `exports/${assetId}.${format}.json`;
}

export function registerSbomEngine(ipcMain: IpcMain): void {
  ipcMain.handle("sbom:generate", async (_e, assetId: string) => generateSbom(assetId));
  ipcMain.handle("sbom:export", async (_e, args: { assetId: string; format: "cyclonedx" | "spdx" }) =>
    exportSbom(args.assetId, args.format)
  );
}
