// engine/cryptopack.ts — 민감 보안데이터 암호화 유틸
// 고객사 자산·스캔결과 등을 로컬에 저장할 때 사용.

import type { IpcMain } from "electron";
import * as crypto from "crypto";

export function encryptBuffer(data: Buffer, key: Buffer): { iv: Buffer; ciphertext: Buffer } {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([cipher.update(data), cipher.final()]);
  return { iv, ciphertext };
}

export function registerCryptopackEngine(ipcMain: IpcMain): void {
  // TODO: 키 관리 정책 결정 후 IPC 채널 노출 여부 결정 (기본적으로 메인 프로세스 내부용)
}
