// engine/report.ts — 내부 SBOM 기반 내부보고용 리포트
// 로컬LLM_프로젝트_가이드.md 6.4.1절 구현체.

import type { IpcMain } from "electron";
import { chat } from "./llm";

export interface ReportRequest {
  type: "weekly" | "quarterly" | "ondemand";
  assetIds?: string[];
}

export interface ReportResult {
  filePath: string;
  executiveSummary: string;
}

export async function generateReport(req: ReportRequest): Promise<ReportResult> {
  // 1) SBOM/자산 데이터 취합 (sbom.ts, engine 내부 호출)
  // 2) LLM으로 경영진 요약 생성
  const executiveSummary = await chat({
    agentId: "report",
    message: `다음 보안 현황 데이터를 바탕으로 경영진용 1페이지 요약을 작성해줘: ${JSON.stringify(req)}`,
  });
  // 3) docx/pdfkit/exceljs로 실제 문서 렌더링
  // TODO: 템플릿 엔진 연결
  return { filePath: `reports/${req.type}-${Date.now()}.docx`, executiveSummary };
}

export function registerReportEngine(ipcMain: IpcMain): void {
  ipcMain.handle("report:generate", async (_e, req: ReportRequest) => generateReport(req));
}
