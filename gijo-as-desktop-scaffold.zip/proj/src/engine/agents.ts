// engine/agents.ts — 에이전트 정의 및 페르소나
// 로컬LLM_프로젝트_가이드.md 6단계에서 확정한 8종 보안 에이전트를 정의한다.
// dispatcher.ts가 작업 할당/완료 시 상태(status)를 갱신한다.

import type { IpcMain } from "electron";

export type AgentStatus = "idle" | "working" | "watching";

export interface AgentDefinition {
  id: string;
  name: string;
  role: string;
  brainModelId: string; // localengine 또는 hfmodels에서 로드한 모델 식별자
  status: AgentStatus;
  defaultStatus: AgentStatus; // 작업 완료 후 되돌아갈 기본 상태 (watching형 에이전트는 idle이 아니라 watching으로 복귀)
}

// 모듈 내부 가변 상태 — 실제로는 sqlite/lowdb 등으로 영속화할 것 (현재는 인메모리)
const agents: AgentDefinition[] = [
  { id: "orchestrator", name: "오케스트레이터", role: "작업 분배 · 결과 취합", brainModelId: "qwen3-30b-a3b", status: "watching", defaultStatus: "watching" },
  { id: "scan", name: "스캔 에이전트", role: "정적분석 실행 (ModelScan)", brainModelId: "qwen3-30b-a3b", status: "idle", defaultStatus: "idle" },
  { id: "pentest", name: "침투테스트 에이전트", role: "익스플로잇 검증 (Penligent)", brainModelId: "deephat-v1-7b", status: "idle", defaultStatus: "idle" },
  { id: "analysis", name: "분석 에이전트", role: "우선순위 판단 · 설명", brainModelId: "foundation-sec-8b", status: "idle", defaultStatus: "idle" },
  { id: "sbom", name: "SBOM 에이전트", role: "SBOM 생성 · 정리", brainModelId: "qwen3-30b-a3b", status: "idle", defaultStatus: "idle" },
  { id: "cti", name: "CTI 에이전트", role: "딥웹 · 다크웹 감시", brainModelId: "qwen3-30b-a3b", status: "watching", defaultStatus: "watching" },
  { id: "report", name: "리포트 에이전트", role: "내부 보고서 작성", brainModelId: "qwen3-30b-a3b", status: "idle", defaultStatus: "idle" },
  { id: "model-evolution", name: "모델 진화 에이전트", role: "보안 특화 LLM 병합", brainModelId: "merge-experiment", status: "idle", defaultStatus: "idle" },
];

export function getAgentById(id: string): AgentDefinition | undefined {
  return agents.find((a) => a.id === id);
}

export function setAgentStatus(id: string, status: AgentStatus): AgentDefinition | undefined {
  const agent = getAgentById(id);
  if (agent) agent.status = status;
  return agent;
}

export function resetAgentToDefault(id: string): AgentDefinition | undefined {
  const agent = getAgentById(id);
  if (agent) agent.status = agent.defaultStatus;
  return agent;
}

export function listAgents(): AgentDefinition[] {
  return agents;
}

export function registerAgentsEngine(ipcMain: IpcMain): void {
  ipcMain.handle("agents:list", async () => listAgents());
}
