// engine/cti.ts — 딥웹 · 다크웹 CTI 피드 연동
// 로컬LLM_프로젝트_가이드.md 6.1.1절 구현체.
// LLM이 직접 다크웹을 크롤링하지 않고, 라이선스 CTI 벤더 API만 호출한다.

import type { IpcMain } from "electron";

export interface CtiFeedConfig {
  id: string;
  name: string;
  apiKey: string;
  connected: boolean;
}

export interface CtiFinding {
  id: string;
  detectedAt: string;
  type: string;
  target: string;
  source: string;
  severity: "info" | "warning" | "critical";
}

const feeds: CtiFeedConfig[] = [
  { id: "criminalip", name: "Criminal IP", apiKey: "", connected: false },
  { id: "flashpoint", name: "Flashpoint", apiKey: "", connected: false },
  { id: "spycloud", name: "SpyCloud", apiKey: "", connected: false },
];

export async function listFindings(): Promise<CtiFinding[]> {
  // TODO: 연결된 각 피드의 REST API를 호출해 최근 탐지 내역 취합
  return [];
}

export function registerCtiEngine(ipcMain: IpcMain): void {
  ipcMain.handle("cti:listFeeds", async () => feeds);
  ipcMain.handle("cti:listFindings", async () => listFindings());
}
