// engine/email.ts — 내부 리포트 이메일 발송
// 로컬LLM_프로젝트_가이드.md 6.4.1절과 연결.

import type { IpcMain } from "electron";

export interface SendReportEmailArgs {
  to: string[];
  subject: string;
  attachmentPath: string;
}

export async function sendReportEmail(args: SendReportEmailArgs): Promise<void> {
  // TODO: nodemailer 등으로 SMTP 발송 구현 (사내 메일 서버 연동)
}

export function registerEmailEngine(ipcMain: IpcMain): void {
  ipcMain.handle("email:sendReport", async (_e, args: SendReportEmailArgs) => sendReportEmail(args));
}
