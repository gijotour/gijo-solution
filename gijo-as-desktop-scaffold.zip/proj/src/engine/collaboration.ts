// engine/collaboration.ts — 에이전트 간 작업 위임 · 협업 로그
// 에이전트 AI 화면의 "실시간 협업 현황" 피드를 구동한다.

import type { IpcMain, BrowserWindow } from "electron";

export interface CollaborationEvent {
  from: string;
  to: string;
  message: string;
  timestamp: number;
}

const log: CollaborationEvent[] = [];

export function emitCollaboration(win: BrowserWindow, evt: Omit<CollaborationEvent, "timestamp">): void {
  const full: CollaborationEvent = { ...evt, timestamp: Date.now() };
  log.push(full);
  win.webContents.send("collaboration:event", full);
}

export function registerCollaborationEngine(ipcMain: IpcMain): void {
  ipcMain.handle("collaboration:history", async () => log.slice(-100));
  // TODO: 실제 에이전트 실행 파이프라인(bridge.ts, llm.ts)에서
  // 작업 단계마다 emitCollaboration()을 호출하도록 연결
}
