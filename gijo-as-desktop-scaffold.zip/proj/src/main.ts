// GIJO AS — Electron 메인 프로세스
// 설계 원칙: main.ts는 얇게 유지하고, 기능 로직은 전부 engine/ 아래 모듈로 분리한다.
// (로컬LLM_프로젝트_가이드.md 7단계 "적용 방침 2" 참고)

import { app, BrowserWindow, ipcMain } from "electron";
import * as path from "path";

import { registerAgentsEngine } from "./engine/agents";
import { registerDispatcherEngine } from "./engine/dispatcher";
import { registerMemoryEngine } from "./engine/memory";
import { registerBridgeEngine } from "./engine/bridge";
import { registerCollaborationEngine } from "./engine/collaboration";
import { registerDatasetEngine } from "./engine/dataset";
import { registerGitSyncEngine } from "./engine/gitsync";
import { registerHfModelsEngine } from "./engine/hfmodels";
import { registerIntentEngine } from "./engine/intent";
import { registerLlmEngine } from "./engine/llm";
import { registerLocalEngine } from "./engine/localengine";
import { registerFinetuneEngine } from "./engine/finetune";
import { registerToolsEngine } from "./engine/tools";
import { registerTasksEngine } from "./engine/tasks";
import { registerEmailEngine } from "./engine/email";
import { registerCryptopackEngine } from "./engine/cryptopack";
import { registerSbomEngine } from "./engine/sbom";
import { registerCtiEngine } from "./engine/cti";
import { registerReportEngine } from "./engine/report";

let mainWindow: BrowserWindow | null = null;

function createMainWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1180,
    minHeight: 720,
    backgroundColor: "#0a0e1a",
    title: "GIJO AS — AI Security Manager OS",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  // 초기 화면은 대시보드(에이전트 네트워크 뷰). 사이드바 nav 클릭 시
  // renderer/core.ts가 IPC(navigate:to)로 다른 페이지를 요청한다.
  mainWindow.loadFile(path.join(__dirname, "../src/renderer/pages/dashboard.html"));

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

/**
 * 각 engine 모듈은 자신의 IPC 채널만 등록한다(단일 책임).
 * 모듈 목록은 로컬LLM_프로젝트_가이드.md 7.2절 "엔진 모듈 대응표"와 1:1로 대응한다.
 */
function registerAllEngines(): void {
  registerAgentsEngine(ipcMain);
  registerDispatcherEngine(ipcMain);
  registerMemoryEngine(ipcMain);
  registerBridgeEngine(ipcMain);
  registerCollaborationEngine(ipcMain);
  registerDatasetEngine(ipcMain);
  registerGitSyncEngine(ipcMain);
  registerHfModelsEngine(ipcMain);
  registerIntentEngine(ipcMain);
  registerLlmEngine(ipcMain);
  registerLocalEngine(ipcMain);
  registerFinetuneEngine(ipcMain);
  registerToolsEngine(ipcMain);
  registerTasksEngine(ipcMain);
  registerEmailEngine(ipcMain);
  registerCryptopackEngine(ipcMain);
  registerSbomEngine(ipcMain);
  registerCtiEngine(ipcMain);
  registerReportEngine(ipcMain);
}

app.whenReady().then(() => {
  registerAllEngines();
  createMainWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
