// renderer/core.ts — 렌더러 공통 로직
// 각 페이지 HTML에 <script src="../core.js"></script>로 포함해 사용한다.
// window.gijo.* 는 preload.ts가 노출한 안전한 IPC 래퍼.

declare global {
  interface Window {
    gijo: {
      navigateTo: (page: string) => Promise<void>;
      listAgents: () => Promise<unknown[]>;
      sendInstruction: (text: string) => Promise<unknown>;
      listAssets: () => Promise<unknown[]>;
      listTasks: () => Promise<unknown[]>;
      chat: (agentId: string, message: string) => Promise<string>;
    };
  }
}

function wireSidebarNavigation(): void {
  document.querySelectorAll<HTMLElement>(".nav-item[data-page]").forEach((el) => {
    el.addEventListener("click", () => {
      const page = el.dataset.page;
      if (page) window.gijo.navigateTo(page);
    });
  });
}

function wireChatBar(): void {
  const input = document.querySelector<HTMLInputElement>(".chatbar input");
  if (!input) return;
  input.addEventListener("keydown", async (e) => {
    if (e.key === "Enter" && input.value.trim()) {
      await window.gijo.sendInstruction(input.value.trim());
      input.value = "";
    }
  });
}

window.addEventListener("DOMContentLoaded", () => {
  wireSidebarNavigation();
  wireChatBar();
  // TODO: 페이지별로 필요한 초기 데이터 로드(listAgents/listAssets/listTasks)를
  // 각 page.html 하단에 추가 스크립트로 연결
});

export {};
