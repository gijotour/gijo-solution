// GIJO AS — preload 스크립트
// contextIsolation 환경에서 렌더러가 접근 가능한 안전한 API 표면을 정의한다.
// 렌더러는 window.gijo.* 로만 메인 프로세스와 통신하며, Node API에 직접 접근하지 않는다.

import { contextBridge, ipcRenderer } from "electron";

const gijoApi = {
  // 네비게이션
  navigateTo: (page: string) => ipcRenderer.invoke("navigate:to", page),

  // 에이전트 AI
  listAgents: () => ipcRenderer.invoke("agents:list"),
  sendInstruction: (text: string) => ipcRenderer.invoke("dispatcher:run", text),
  onCollaborationEvent: (cb: (evt: unknown) => void) =>
    ipcRenderer.on("collaboration:event", (_e, evt) => cb(evt)),

  // 자산 / SBOM
  listAssets: () => ipcRenderer.invoke("assets:list"),
  generateSbom: (assetId: string) => ipcRenderer.invoke("sbom:generate", assetId),
  exportSbom: (assetId: string, format: "cyclonedx" | "spdx") =>
    ipcRenderer.invoke("sbom:export", { assetId, format }),

  // 로컬 LLM
  getLocalEngineStatus: () => ipcRenderer.invoke("localengine:status"),
  startLocalEngine: (modelId: string) => ipcRenderer.invoke("localengine:start", modelId),
  chat: (agentId: string, message: string) =>
    ipcRenderer.invoke("llm:chat", { agentId, message }),

  // 메모리 (RAG / 파인튜닝)
  ingestDocument: (path: string) => ipcRenderer.invoke("memory:ingest", path),
  startFinetune: (agentId: string, datasetId: string) =>
    ipcRenderer.invoke("finetune:start", { agentId, datasetId }),
  onFinetuneProgress: (cb: (p: unknown) => void) =>
    ipcRenderer.on("finetune:progress", (_e, p) => cb(p)),

  // HuggingFace 모델 검색
  searchHfModels: (query: string) => ipcRenderer.invoke("hfmodels:search", query),
  loadHfModel: (modelId: string) => ipcRenderer.invoke("hfmodels:load", modelId),

  // CTI (딥웹/다크웹 피드)
  listCtiFeeds: () => ipcRenderer.invoke("cti:listFeeds"),
  listCtiFindings: () => ipcRenderer.invoke("cti:listFindings"),

  // 내부 리포트
  generateReport: (opts: { type: "weekly" | "quarterly" | "ondemand"; assetIds?: string[] }) =>
    ipcRenderer.invoke("report:generate", opts),

  // 작업 큐 (오늘 확인할 항목)
  listTasks: () => ipcRenderer.invoke("tasks:list"),
  addTask: (text: string) => ipcRenderer.invoke("tasks:add", text),
};

contextBridge.exposeInMainWorld("gijo", gijoApi);

export type GijoApi = typeof gijoApi;
